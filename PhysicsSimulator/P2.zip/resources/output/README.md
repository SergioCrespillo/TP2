# out.1.json

* was generated using the commnd-line

  -i resources/examples/ex1.2body.json -o resources/output/out.1.json -s 10000 -dt 10000 -fl nlug

* check equivalence using the commnd-line

  -i resources/examples/ex1.2body.json -eo resources/output/out.1.json -s 10000 -dt 10000 -fl nlug

* check epsilon-equivalence (with eps=0.1) using the commnd-line

  -i resources/examples/ex1.2body.json -eo resources/output/out.1.json -s 10000 -dt 10000 -fl nlug-cmp espeq:{eps:0.1}

# out.2.json

* was generated using the commnd-line

  -i resources/examples/ex1.2body.json -o resources/output/out.2.json -s 10000 -dt 10000 -fl mtfp

* check equivalence using the commnd-line

  -i resources/examples/ex1.2body.json -eo resources/output/out.2.json -s 10000 -dt 10000 -fl mtfp

* check epsilon-equivalence (with eps=0.1) using the commnd-line

  -i resources/examples/ex1.2body.json -eo resources/output/out.2.json -s 10000 -dt 10000 -fl mtfp-cmp espeq:{eps:0.1}

# out.3.json

* was generated using the commnd-line

  -i resources/examples/ex2.3body.json -o resources/output/out.3.json -s 10000 -dt 10000 -fl nlug

* check equivalence using the commnd-line

  -i resources/examples/ex2.3body.json -eo resources/output/out.3.json -s 10000 -dt 10000 -fl nlug

* check epsilon-equivalence (with eps=0.1) using the commnd-line

  -i resources/examples/ex2.3body.json -eo resources/output/out.3.json -s 10000 -dt 10000 -fl nlug-cmp espeq:{eps:0.1}

# out.4.json

* was generated using the commnd-line

  -i resources/examples/ex2.3body.json -o resources/output/out.4.json -s 10000 -dt 10000 -fl mtfp

* check equivalence using the commnd-line

  -i resources/examples/ex2.3body.json -eo resources/output/out.4.json -s 10000 -dt 10000 -fl mtfp

* check epsilon-equivalence (with eps=0.1) using the commnd-line

  -i resources/examples/ex2.3body.json -eo resources/output/out.4.json -s 10000 -dt 10000 -fl mtfp-cmp espeq:{eps:0.1}

# out.5.json

* was generated using the commnd-line

  -i resources/examples/ex3.4body.json -o resources/output/out.5.json -s 10000 -dt 10000 -fl nlug

* check equivalence using the commnd-line

  -i resources/examples/ex3.4body.json -eo resources/output/out.5.json -s 10000 -dt 10000 -fl nlug

* check epsilon-equivalence (with eps=0.1) using the commnd-line

  -i resources/examples/ex3.4body.json -eo resources/output/out.5.json -s 10000 -dt 10000 -fl nlug-cmp espeq:{eps:0.1}

# out.6.json

* was generated using the commnd-line

  -i resources/examples/ex3.4body.json -o resources/output/out.6.json -s 10000 -dt 10000 -fl mtfp

* check equivalence using the commnd-line

  -i resources/examples/ex3.4body.json -eo resources/output/out.6.json -s 10000 -dt 10000 -fl mtfp

* check epsilon-equivalence (with eps=0.1) using the commnd-line

  -i resources/examples/ex3.4body.json -eo resources/output/out.6.json -s 10000 -dt 10000 -fl mtfp-cmp espeq:{eps:0.1}

# out.7.json

* was generated using the commnd-line

  -i resources/examples/ex4.4body.json -o resources/output/out.7.json -s 10000 -dt 10000 -fl nlug

* check equivalence using the commnd-line

  -i resources/examples/ex4.4body.json -eo resources/output/out.7.json -s 10000 -dt 10000 -fl nlug

* check epsilon-equivalence (with eps=0.1) using the commnd-line

  -i resources/examples/ex4.4body.json -eo resources/output/out.7.json -s 10000 -dt 10000 -fl nlug-cmp espeq:{eps:0.1}

# out.8.json

* was generated using the commnd-line

  -i resources/examples/ex4.4body.json -o resources/output/out.8.json -s 10000 -dt 10000 -fl mtfp

* check equivalence using the commnd-line

  -i resources/examples/ex4.4body.json -eo resources/output/out.8.json -s 10000 -dt 10000 -fl mtfp

* check epsilon-equivalence (with eps=0.1) using the commnd-line

  -i resources/examples/ex4.4body.json -eo resources/output/out.8.json -s 10000 -dt 10000 -fl mtfp-cmp espeq:{eps:0.1}

# out.1s.json

* was generated using the commnd-line

  -i resources/examples/ex1.2body.json -o resources/output/out.1s.json -s 10000 -fl nlug

* check equivalence using the commnd-line

  -i resources/examples/ex1.2body.json -eo resources/output/out.1s.json -s 10000 -fl nlug

* check epsilon-equivalence (with eps=0.1) using the commnd-line

  -i resources/examples/ex1.2body.json -eo resources/output/out.1s.json -s 10000 -fl nlug-cmp espeq:{eps:0.1}

# out.2s.json

* was generated using the commnd-line

  -i resources/examples/ex1.2body.json -o resources/output/out.2s.json -s 10000 -fl mtfp

* check equivalence using the commnd-line

  -i resources/examples/ex1.2body.json -eo resources/output/out.2s.json -s 10000 -fl mtfp

* check epsilon-equivalence (with eps=0.1) using the commnd-line

  -i resources/examples/ex1.2body.json -eo resources/output/out.2s.json -s 10000 -fl mtfp-cmp espeq:{eps:0.1}

# out.3s.json

* was generated using the commnd-line

  -i resources/examples/ex2.3body.json -o resources/output/out.3s.json -s 10000 -fl nlug

* check equivalence using the commnd-line

  -i resources/examples/ex2.3body.json -eo resources/output/out.3s.json -s 10000 -fl nlug

* check epsilon-equivalence (with eps=0.1) using the commnd-line

  -i resources/examples/ex2.3body.json -eo resources/output/out.3s.json -s 10000 -fl nlug-cmp espeq:{eps:0.1}

# out.4s.json

* was generated using the commnd-line

  -i resources/examples/ex2.3body.json -o resources/output/out.4s.json -s 10000 -fl mtfp

* check equivalence using the commnd-line

  -i resources/examples/ex2.3body.json -eo resources/output/out.4s.json -s 10000 -fl mtfp

* check epsilon-equivalence (with eps=0.1) using the commnd-line

  -i resources/examples/ex2.3body.json -eo resources/output/out.4s.json -s 10000 -fl mtfp-cmp espeq:{eps:0.1}

# out.5s.json

* was generated using the commnd-line

  -i resources/examples/ex3.4body.json -o resources/output/out.5s.json -s 10000 -fl nlug

* check equivalence using the commnd-line

  -i resources/examples/ex3.4body.json -eo resources/output/out.5s.json -s 10000 -fl nlug

* check epsilon-equivalence (with eps=0.1) using the commnd-line

  -i resources/examples/ex3.4body.json -eo resources/output/out.5s.json -s 10000 -fl nlug-cmp espeq:{eps:0.1}

# out.6s.json

* was generated using the commnd-line

  -i resources/examples/ex3.4body.json -o resources/output/out.6s.json -s 10000 -fl mtfp

* check equivalence using the commnd-line

  -i resources/examples/ex3.4body.json -eo resources/output/out.6s.json -s 10000 -fl mtfp

* check epsilon-equivalence (with eps=0.1) using the commnd-line

  -i resources/examples/ex3.4body.json -eo resources/output/out.6s.json -s 10000 -fl mtfp-cmp espeq:{eps:0.1}

# out.7s.json

* was generated using the commnd-line

  -i resources/examples/ex4.4body.json -o resources/output/out.7s.json -s 10000 -fl nlug

* check equivalence using the commnd-line

  -i resources/examples/ex4.4body.json -eo resources/output/out.7s.json -s 10000 -fl nlug

* check epsilon-equivalence (with eps=0.1) using the commnd-line

  -i resources/examples/ex4.4body.json -eo resources/output/out.7s.json -s 10000 -fl nlug-cmp espeq:{eps:0.1}

# out.8s.json

* was generated using the commnd-line

  -i resources/examples/ex4.4body.json -o resources/output/out.8s.json -s 10000 -fl mtfp

* check equivalence using the commnd-line

  -i resources/examples/ex4.4body.json -eo resources/output/out.8s.json -s 10000 -fl mtfp

* check epsilon-equivalence (with eps=0.1) using the commnd-line

  -i resources/examples/ex4.4body.json -eo resources/output/out.8s.json -s 10000 -fl mtfp-cmp espeq:{eps:0.1}

